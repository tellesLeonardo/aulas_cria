defmodule Floki.ParseError do
  defexception [:message]
end
