defmodule AulasCria.Mailer do
  use Swoosh.Mailer, otp_app: :aulas_cria
end
